"""passlib - suite of password hashing & generation routines"""
import sys, os

packagepath = os.getcwd() + 'passlib'
sys.path.append(packagepath)

__version__ = '1.7.4'

