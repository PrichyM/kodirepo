1)  Create menu option
2)  Set ID
3)  Optional: Create widget for appropriet menu option and set number of posters and set XML file name
3b) Create node in userdata/library/video/REPLACE_WITH_MENU_ID/REPLACE_WITH_XML_FILE_NAME.xml

-------------------------------------------------------------------------------------------------------------
XML example

<?xml version='1.0' encoding='UTF-8'?>
<node order="10" type="folder">
    <label>Novinky</label>
    <icon>DefaultRecentlyAddedMovies.png</icon>
    <path>plugin://plugin.video.stream-cinema-2-release/get_media/?media_type=movie&amp;render_type=default&amp;url=%252Fapi%252Fmedia%252Ffilter%252Fv2%252Fnews%253Fdays%253D365%2526type%253Dmovie%2526sort%253DdateAdded%2526order%253Ddesc%2526size%253D50</path>
    <limit>10</limit>
</node>

-------------------------------------------------------------------------------------------------------------


Notes

Script makes copy of estuary skin to addons/skin.estuary.bf folder and then includes changes set in settings
